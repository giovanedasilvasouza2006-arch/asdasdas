
import { BibleBook, Verse } from "../types";
import { BIBLE_BOOKS_FALLBACK } from "../data/bible-metadata";

const API_BASE = "https://bolls.life";

export const AVAILABLE_TRANSLATIONS = [
  { id: "ARA", name: "Almeida Revista e Atualizada" },
  { id: "ALMEIDA", name: "João Ferreira de Almeida" },
  { id: "PORARA", name: "Almeida Revista e Atualizada (Alt)" },
  { id: "PTA", name: "Tradução Brasileira" },
  { id: "ACF", name: "Almeida Corrigida Fiel" },
  { id: "VIVA", name: "Bíblia Viva" },
];

const TRANSLATIONS_TO_TRY = AVAILABLE_TRANSLATIONS.map(t => t.id);

export async function fetchBooks(forcedTrans?: string): Promise<BibleBook[]> {
  const translations = forcedTrans ? [forcedTrans, ...TRANSLATIONS_TO_TRY.filter(t => t !== forcedTrans)] : TRANSLATIONS_TO_TRY;
  
  for (const trans of translations) {
    try {
      const url = `${API_BASE}/get-books/${trans}/`;
      const response = await fetch(url);
      
      const text = await response.text();
      if (text.trim().startsWith("<!DOCTYPE") || !response.ok) {
        continue;
      }

      const data = JSON.parse(text);
      if (Array.isArray(data) && data.length > 0) {
        (window as any).workingTranslation = trans;
        
        return data.map((b: any) => ({
          id: b.bookid,
          name: b.name,
          chapters: b.chapters,
          testament: b.bookid <= 39 ? 'AT' : 'NT'
        }));
      }
    } catch (error) {
      console.warn(`Error trying translation ${trans}:`, error);
    }
  }
  
  // Return fallback if all attempts fail
  console.log("Using fallback bible metadata");
  (window as any).workingTranslation = "ARA"; // Default translation for verses
  return BIBLE_BOOKS_FALLBACK;
}

export async function fetchVerses(bookId: number, chapter: number, forcedTrans?: string): Promise<Verse[]> {
  const workingTrans = forcedTrans || (window as any).workingTranslation;
  const translations = workingTrans 
    ? [workingTrans, ...TRANSLATIONS_TO_TRY.filter(t => t !== workingTrans)]
    : TRANSLATIONS_TO_TRY;

  for (const trans of translations) {
    try {
      const url = `${API_BASE}/get-chapter/${trans}/${bookId}/${chapter}/`;
      const response = await fetch(url);
      
      const text = await response.text();
      if (text.trim().startsWith("<!DOCTYPE") || !response.ok) {
        continue;
      }

      const data = JSON.parse(text);
      if (Array.isArray(data)) {
        // If this one worked and wasn't our working translation, update it
        if (trans !== workingTrans) {
          (window as any).workingTranslation = trans;
        }

        return data.map((v: any) => ({
          pk: v.pk,
          verse: v.verse,
          text: v.text
        }));
      }
    } catch (error) {
      console.warn(`Error fetching verses for ${trans}:`, error);
    }
  }

  console.error("All translation attempts failed for verses");
  return [];
}
