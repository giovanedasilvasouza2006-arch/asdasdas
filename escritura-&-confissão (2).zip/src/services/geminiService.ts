import { GoogleGenAI, Type } from "@google/genai";
import { VerseStudy } from "../types";

let genAI: GoogleGenAI | null = null;

function getAI() {
  if (!genAI) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY não configurada. Por favor, adicione-a nas variáveis de ambiente do seu deploy.");
    }
    genAI = new GoogleGenAI({ apiKey });
  }
  return genAI;
}

export async function getVerseStudy(verseText: string, verseRef: string): Promise<VerseStudy> {
  const ai = getAI();
  const prompt = `Analise o versículo bíblico "${verseRef}: ${verseText}". 
  Gere um estudo completo incluindo:
  1. Um mapa mental (nós e conexões) que explore o significado teológico, conceitos chave e aplicações práticas.
  2. Referências cruzadas (outros versículos relacionados) com uma breve explicação do motivo.
  3. Um comentário breve e profundo.
  4. Temas principais relacionados (ex: Amor, Justiça, Fé).
  
  Responda em PORTUGUÊS.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          mindMap: {
            type: Type.OBJECT,
            properties: {
              nodes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    label: { type: Type.STRING },
                    type: { 
                      type: Type.STRING,
                      enum: ['central', 'concept', 'application', 'reference']
                    }
                  },
                  required: ['id', 'label', 'type']
                }
              },
              edges: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    from: { type: Type.STRING },
                    to: { type: Type.STRING }
                  },
                  required: ['from', 'to']
                }
              }
            },
            required: ['nodes', 'edges']
          },
          references: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                verse: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ['verse', 'description']
            }
          },
          commentary: { type: Type.STRING },
          themes: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ['mindMap', 'references', 'commentary', 'themes']
      }
    }
  });

  return JSON.parse(response.text || '{}') as VerseStudy;
}
