/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { Heart, Coins, Users, X } from "lucide-react";

interface DonationPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DonationPopup({ isOpen, onClose }: DonationPopupProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-md overflow-hidden rounded-3xl bg-sacred-bg p-8 shadow-2xl"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-sacred-accent hover:bg-black/5 rounded-full transition-colors"
            >
              <X size={20} />
            </button>

            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-4 rounded-2xl bg-sacred-accent/10 text-sacred-accent">
                <Heart size={32} fill="currentColor" fillOpacity={0.2} />
              </div>
              <h2 className="text-2xl font-serif font-semibold text-sacred-ink">Ajude na Obra</h2>
              <p className="mt-2 text-sacred-ink/60 text-sm">
                Sua contribuição permite que a Palavra alcance mais corações através da tecnologia e da missão no campo.
              </p>
            </div>

            <div className="space-y-4">
              <button
                onClick={() => window.open('https://example.com/doe-plataforma', '_blank')}
                className="group w-full flex items-center gap-4 p-4 rounded-2xl border border-sacred-accent/20 bg-white hover:bg-sacred-accent hover:text-white transition-all duration-300 text-left"
              >
                <div className="p-3 rounded-xl bg-sacred-accent/10 group-hover:bg-white/20">
                  <Coins className="text-sacred-accent group-hover:text-white" size={24} />
                </div>
                <div>
                  <div className="font-semibold">Plataforma e Produção</div>
                  <div className="text-xs opacity-70 group-hover:opacity-90">Novas funcionalidades e estudos</div>
                </div>
              </button>

              <button
                onClick={() => window.open('https://example.com/doe-missionarios', '_blank')}
                className="group w-full flex items-center gap-4 p-4 rounded-2xl border border-sacred-accent/20 bg-white hover:bg-sacred-accent hover:text-white transition-all duration-300 text-left"
              >
                <div className="p-3 rounded-xl bg-sacred-accent/10 group-hover:bg-white/20">
                  <Users className="text-sacred-accent group-hover:text-white" size={24} />
                </div>
                <div>
                  <div className="font-semibold">Missionários em Guanambi</div>
                  <div className="text-xs opacity-70 group-hover:opacity-90">Apoio direto ao campo em Bahia</div>
                </div>
              </button>
            </div>

            <p className="mt-8 text-center text-xs text-sacred-ink/40">
              "Cada um dê conforme determinou em seu coração, não com pesar nem por obrigação."
            </p>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
