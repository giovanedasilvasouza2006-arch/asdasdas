/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { BookOpen, Map, MessageSquare, Tag, ExternalLink, Check, PenLine, Lock } from "lucide-react";
import { VerseStudy } from "../types";
import { MindMap } from "./MindMap";
import { cn } from "../lib/utils";

interface StudyPanelProps {
  study: VerseStudy;
  isLoading: boolean;
  onReferenceClick: (ref: string) => void;
  onComplete?: () => void;
  isCompleted?: boolean;
  isLoggedIn?: boolean;
}

export function StudyPanel({ 
  study, 
  isLoading, 
  onReferenceClick, 
  onComplete, 
  isCompleted,
  isLoggedIn 
}: StudyPanelProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <motion.div
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-16 h-16 rounded-full border-4 border-sacred-accent/20 border-t-sacred-accent mb-4"
        />
        <p className="text-sacred-accent font-serif italic">Inspirando estudo profundo...</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="space-y-8"
    >
      {/* Completion Button */}
      <div className="flex justify-center">
        <button
          onClick={onComplete}
          disabled={isCompleted}
          className={cn(
            "w-full py-4 rounded-2xl font-bold transition-all shadow-lg flex items-center justify-center gap-2",
            isCompleted 
              ? "bg-green-500/10 text-green-600 border border-green-500/20 cursor-default"
              : "bg-sacred-accent text-white hover:scale-[1.02] active:scale-[0.98] shadow-sacred-accent/20"
          )}
        >
          {isCompleted ? (
            <>
              <Check size={20} />
              Estudo Concluído
            </>
          ) : (
            <>
              <BookOpen size={20} />
              Marcar como Estudado
            </>
          )}
        </button>
      </div>

      {/* Mind Map Section */}
      <section>
        <div className="flex items-center gap-2 mb-6 text-sacred-accent font-semibold uppercase tracking-widest text-xs">
          <Map size={16} />
          <span>Mapa Mental Teológico</span>
        </div>
        <div className="bg-white/40 rounded-3xl p-4 border border-black/5 shadow-inner">
          <MindMap nodes={study.mindMap.nodes} edges={study.mindMap.edges} />
        </div>
      </section>

      {/* Commentary */}
      <section>
        <div className="flex items-center gap-2 mb-4 text-sacred-accent font-semibold uppercase tracking-widest text-xs">
          <MessageSquare size={16} />
          <span>Comentário</span>
        </div>
        <div className="glass-panel rounded-2xl p-6 bible-text text-lg italic opacity-90 relative overflow-hidden">
           <div className="absolute top-0 left-0 w-1 h-full bg-sacred-accent/30" />
           {study.commentary}
        </div>
      </section>

      {/* Donation Promp In between */}
      <div className="p-6 bg-sacred-accent/5 rounded-2xl border border-sacred-accent/10 text-center animate-pulse-slow">
        <p className="text-xs text-sacred-accent font-medium mb-3 tracking-wide">ESTA FERRAMENTA AJUDA VOCÊ?</p>
        <button 
          onClick={() => (window as any).setIsDonationOpen?.(true)}
          className="text-xs px-4 py-2 bg-sacred-accent text-white rounded-full font-bold hover:opacity-90 transition-opacity"
        >
          Apoie os Missionários de Guanambi
        </button>
      </div>

      {/* References */}
      <section>
        <div className="flex items-center gap-2 mb-4 text-sacred-accent font-semibold uppercase tracking-widest text-xs">
          <BookOpen size={16} />
          <span>Referências Cruzadas</span>
        </div>
        <div className="grid gap-3">
          {study.references.map((ref, i) => (
            <button
              key={i}
              onClick={() => onReferenceClick(ref.verse)}
              className="flex items-start gap-4 p-4 rounded-xl bg-white border border-black/5 hover:border-sacred-accent/30 hover:shadow-md transition-all text-left group"
            >
              <div className="min-w-[100px] font-serif font-bold text-sacred-accent">{ref.verse}</div>
              <div className="text-sm text-sacred-ink/70 flex-1">{ref.description}</div>
              <ExternalLink size={14} className="opacity-0 group-hover:opacity-100 transition-opacity text-sacred-accent" />
            </button>
          ))}
        </div>
      </section>

      {/* Themes */}
      <section>
        <div className="flex items-center gap-2 mb-4 text-sacred-accent font-semibold uppercase tracking-widest text-xs">
          <Tag size={16} />
          <span>Temas Relacionados</span>
        </div>
        <div className="flex flex-wrap gap-2 text-wrap">
          {study.themes.map((theme, i) => (
            <span
              key={i}
              className="px-3 py-1 rounded-full bg-sacred-accent/10 border border-sacred-accent/20 text-sacred-accent text-[10px] font-medium"
            >
              #{theme}
            </span>
          ))}
        </div>
      </section>

      {/* Notes Section with Login Prompt */}
      <section>
        <div className="flex items-center gap-2 mb-4 text-sacred-accent font-semibold uppercase tracking-widest text-xs">
          <PenLine size={16} />
          <span>Anotações Pessoais</span>
        </div>
        
        {isLoggedIn ? (
          <textarea
            placeholder="O que o Senhor falou com você hoje?"
            className="w-full h-40 p-4 bg-white rounded-2xl border border-sacred-border focus:ring-2 focus:ring-sacred-accent/20 focus:border-sacred-accent outline-none resize-none text-sm leading-relaxed"
          />
        ) : (
          <div className="bg-sacred-sidebar/50 border border-sacred-border border-dashed rounded-2xl p-6 text-center">
            <Lock size={24} className="mx-auto text-sacred-muted mb-3 opacity-30" />
            <p className="text-sm text-sacred-muted mb-4 font-medium">Faça login para fazer anotações.</p>
            <button 
              onClick={() => (window as any).signInWithGoogle?.()}
              className="text-xs px-6 py-2 bg-sacred-accent text-white rounded-full font-bold hover:opacity-90 shadow-lg shadow-sacred-accent/20 transition-all"
            >
              Fazer Login
            </button>
          </div>
        )}
      </section>
    </motion.div>
  );
}
