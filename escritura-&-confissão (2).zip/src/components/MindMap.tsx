/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { MindMapNode, MindMapEdge } from "../types";
import { useMemo } from "react";

interface MindMapProps {
  nodes: MindMapNode[];
  edges: MindMapEdge[];
}

export function MindMap({ nodes, edges }: MindMapProps) {
  // Simple force-directed-ish layout positions (static for now for consistency)
  const nodePositions = useMemo(() => {
    const positions: Record<string, { x: number; y: number }> = {};
    const centralNode = nodes.find(n => n.type === 'central');
    
    if (centralNode) {
      positions[centralNode.id] = { x: 200, y: 200 };
      
      const others = nodes.filter(n => n.id !== centralNode.id);
      others.forEach((node, i) => {
        const angle = (i / others.length) * Math.PI * 2;
        const radius = node.type === 'concept' ? 120 : 180;
        positions[node.id] = {
          x: 200 + Math.cos(angle) * radius,
          y: 200 + Math.sin(angle) * radius
        };
      });
    }
    return positions;
  }, [nodes]);

  return (
    <div className="relative w-full aspect-square max-w-[400px] mx-auto overflow-visible select-none">
      <svg className="absolute inset-0 w-full h-full overflow-visible" viewBox="0 0 400 400">
        {edges.map((edge, i) => {
          const from = nodePositions[edge.from];
          const to = nodePositions[edge.to];
          if (!from || !to) return null;
          
          return (
            <motion.line
              key={`${edge.from}-${edge.to}-${i}`}
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.2 }}
              transition={{ duration: 1, delay: 0.5 }}
              x1={from.x}
              y1={from.y}
              x2={to.x}
              y2={to.y}
              stroke="var(--color-sacred-accent)"
              strokeWidth="2"
              strokeDasharray="4 4"
            />
          );
        })}
      </svg>

      {nodes.map((node) => {
        const pos = nodePositions[node.id];
        if (!pos) return null;

        return (
          <motion.div
            key={node.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.2 }}
            className={`absolute flex items-center justify-center p-3 rounded-full text-center text-[10px] font-semibold shadow-sm transition-transform hover:scale-110 cursor-help
              ${node.type === 'central' ? 'w-24 h-24 bg-sacred-accent text-white border-2 border-sacred-border' : 
                node.type === 'concept' ? 'w-20 h-20 bg-white border border-sacred-accent/30 text-sacred-ink' :
                'w-16 h-16 bg-white border border-sacred-border text-sacred-muted'}`}
            style={{
              left: `${(pos.x / 400) * 100}%`,
              top: `${(pos.y / 400) * 100}%`,
              transform: 'translate(-50%, -50%)'
            }}
          >
            <span className="leading-tight">{node.label}</span>
          </motion.div>
        );
      })}
    </div>
  );
}
