export interface ConfessionChapter {
  id: number;
  title: string;
}

export const westminsterConfession: ConfessionChapter[] = [
  { id: 1, title: "Das Escrituras Sagradas" },
  { id: 2, title: "De Deus e da Santíssima Trindade" },
  { id: 3, title: "Dos Decretos Eternos de Deus" },
  { id: 4, title: "Da Criação" },
  { id: 5, title: "Da Providência" },
  { id: 6, title: "Da Queda do Homem, do Pecado e do seu Castigo" },
  { id: 7, title: "Do Pacto de Deus com o Homem" },
  { id: 8, title: "De Cristo, o Mediador" },
  { id: 9, title: "Do Livre Arbítrio" },
  { id: 10, title: "Da Vocação Eficaz" },
  { id: 11, title: "Da Justificação" },
  { id: 12, title: "Da Adoção" },
  { id: 13, title: "Da Santificação" },
  { id: 14, title: "Da Fé Salvador" },
  { id: 15, title: "Do Arrependimento para a Vida" },
  { id: 16, title: "Das Boas Obras" },
  { id: 17, title: "Da Perseverança dos Santos" },
  { id: 18, title: "Da Certeza da Graça e da Salvação" },
  { id: 19, title: "Da Lei de Deus" },
  { id: 20, title: "Da Liberdade Cristã e da Liberdade de Consciência" },
  { id: 21, title: "Do Culto Religioso e do Domingo" },
  { id: 22, title: "Dos Juramentos Legais e dos Votos" },
  { id: 23, title: "Do Magistrado Civil" },
  { id: 24, title: "Do Matrimônio e do Divórcio" },
  { id: 25, title: "Da Igreja" },
  { id: 26, title: "Da Comunhão dos Santos" },
  { id: 27, title: "Dos Sacramentos" },
  { id: 28, title: "Do Batismo" },
  { id: 29, title: "Da Ceia do Senhor" },
  { id: 30, title: "Das Censuras Eclesiásticas" },
  { id: 31, title: "Dos Sínodos e Concílios" },
  { id: 32, title: "Do Estado do Homem depois da Morte e da Ressurreição" },
  { id: 33, title: "Do Juízo Final" }
];
