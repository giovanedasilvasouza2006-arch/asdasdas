/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BibleBook {
  id: number;
  name: string;
  chapters: number;
  testament: 'AT' | 'NT';
}

export interface Verse {
  pk: number;
  verse: number;
  text: string;
}

export interface MindMapNode {
  id: string;
  label: string;
  type: 'central' | 'concept' | 'application' | 'reference';
}

export interface MindMapEdge {
  from: string;
  to: string;
}

export interface VerseStudy {
  mindMap: {
    nodes: MindMapNode[];
    edges: MindMapEdge[];
  };
  references: {
    verse: string;
    description: string;
  }[];
  commentary: string;
  themes: string[];
}
