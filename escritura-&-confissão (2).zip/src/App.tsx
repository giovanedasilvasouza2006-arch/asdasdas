/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { Search, Book, Heart, Menu, X, ChevronRight, Hash, Sparkles, ChevronLeft, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { fetchBooks, fetchVerses, AVAILABLE_TRANSLATIONS } from './services/bibleService';
import { getVerseStudy } from './services/geminiService';
import { BibleBook, Verse, VerseStudy } from './types';
import { westminsterConfession, ConfessionChapter } from './data/confession';
import { StudyPanel } from './components/StudyPanel';
import { DonationPopup } from './components/DonationPopup';
import { cn } from './lib/utils';
import { auth, signInWithGoogle, logOut, markVerseAsStudied, getUserStats } from './services/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

const TOTAL_BIBLE_VERSES = 31102;

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [completedVerses, setCompletedVerses] = useState<Set<string>>(new Set());
  const [books, setBooks] = useState<BibleBook[]>([]);
  const [selectedBook, setSelectedBook] = useState<BibleBook | null>(null);
  const [chapter, setChapter] = useState(1);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [selectedVerse, setSelectedVerse] = useState<Verse | null>(null);
  const [study, setStudy] = useState<VerseStudy | null>(null);
  const [isStudyLoading, setIsStudyLoading] = useState(false);
  const [isDonationOpen, setIsDonationOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentTranslation, setCurrentTranslation] = useState(AVAILABLE_TRANSLATIONS[0].id);
  const [selectedConfession, setSelectedConfession] = useState<ConfessionChapter | null>(null);
  const [completedConfessions, setCompletedConfessions] = useState<Set<string>>(new Set());
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auth observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setIsAuthLoading(false);
      
      if (currentUser) {
        try {
          const stats = await getUserStats(currentUser.uid);
          setCompletedVerses(new Set(stats?.completedVerses || []));
          setCompletedConfessions(new Set(stats?.completedConfessions?.map(String) || []));
        } catch (error) {
          // Errors are already partially handled in getUserStats, 
          // but we catch here to prevent auth flow disruption
          console.warn("Could not load user stats, using defaults:", error);
          setCompletedVerses(new Set());
          setCompletedConfessions(new Set());
        }
      } else {
        setCompletedVerses(new Set());
        setCompletedConfessions(new Set());
      }
    });
    
    // Attach global handlers for components without direct access
    (window as any).setIsDonationOpen = (val: boolean) => setIsDonationOpen(val);
    (window as any).signInWithGoogle = () => signInWithGoogle();
    
    return () => {
      unsubscribe();
      delete (window as any).setIsDonationOpen;
      delete (window as any).signInWithGoogle;
    };
  }, []);

  const [isBooksError, setIsBooksError] = useState(false);

  // Initial load
  const loadBooks = useCallback(() => {
    setIsBooksError(false);
    fetchBooks(currentTranslation).then(data => {
      if (data.length > 0) {
        setBooks(data);
        if (!selectedBook) setSelectedBook(data[0]);
      } else {
        setIsBooksError(true);
      }
    }).catch(() => setIsBooksError(true));
  }, [currentTranslation, selectedBook]);

  useEffect(() => {
    loadBooks();
  }, [loadBooks]);

  const [isVersesError, setIsVersesError] = useState(false);

  // Fetch verses
  const loadVerses = useCallback(() => {
    if (selectedBook) {
      setIsVersesError(false);
      fetchVerses(selectedBook.id, chapter, currentTranslation).then(data => {
        if (data.length > 0) {
          setVerses(data);
        } else {
          setIsVersesError(true);
        }
      }).catch(() => setIsVersesError(true));
      
      setSelectedVerse(null);
      setStudy(null);
      if (scrollRef.current) scrollRef.current.scrollTop = 0;
    }
  }, [selectedBook, chapter, currentTranslation]);

  useEffect(() => {
    loadVerses();
  }, [loadVerses]);

  const handleVerseSelect = useCallback(async (verse: Verse) => {
    if (selectedVerse?.pk === verse.pk) return;
    
    setSelectedVerse(verse);
    setSelectedConfession(null);
    setIsStudyLoading(true);
    setStudy(null);
    
    try {
      const ref = `${selectedBook?.name} ${chapter}:${verse.verse}`;
      const studyData = await getVerseStudy(verse.text, ref);
      setStudy(studyData);
    } catch (error) {
      console.error("Erro no estudo:", error);
    } finally {
      setIsStudyLoading(false);
    }
  }, [selectedBook, chapter, selectedVerse]);

  const handleConfessionSelect = useCallback(async (conf: ConfessionChapter) => {
    if (selectedConfession?.id === conf.id) return;
    
    setSelectedConfession(conf);
    setSelectedVerse(null);
    setIsStudyLoading(true);
    setStudy(null);
    
    try {
      const studyData = await getVerseStudy(`Capítulo ${conf.id}: ${conf.title}`, "Confissão de Fé de Westminster");
      setStudy(studyData);
    } catch (error) {
      console.error("Erro no estudo da CF:", error);
    } finally {
      setIsStudyLoading(false);
    }
  }, [selectedConfession]);

  const handleStudyComplete = useCallback(async () => {
    if (selectedVerse) {
      setCompletedVerses(prev => {
        const next = new Set(prev);
        next.add(selectedVerse.pk.toString());
        return next;
      });

      if (user) {
        await markVerseAsStudied(user.uid, selectedVerse.pk.toString(), 'verse');
      }
    } else if (selectedConfession) {
      setCompletedConfessions(prev => {
        const next = new Set(prev);
        next.add(selectedConfession.id.toString());
        return next;
      });

      if (user) {
        await markVerseAsStudied(user.uid, selectedConfession.id.toString(), 'confession');
      }
    }
  }, [selectedVerse, selectedConfession, user]);

  const handleReferenceClick = useCallback((ref: string) => {
    const bookPart = ref.split(' ')[0];
    const foundBook = books.find(b => b.name.toLowerCase().includes(bookPart.toLowerCase()));
    if (foundBook) {
      setSelectedBook(foundBook);
      const chMatch = ref.match(/(\d+):/);
      if (chMatch) setChapter(parseInt(chMatch[1]));
    }
  }, [books]);

  const filteredBooks = books.filter(b => b.name.toLowerCase().includes(searchQuery.toLowerCase()));

  if (isAuthLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-sacred-bg">
        <motion.div
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-12 h-12 rounded-full border-4 border-sacred-accent/20 border-t-sacred-accent"
        />
      </div>
    );
  }

  // Login is now optional, so we don't return the full-screen login block here.

  return (
    <div className="flex h-screen bg-sacred-bg text-sacred-ink overflow-hidden font-sans">
      {/* Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.aside
            initial={{ x: -260, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -260, opacity: 0 }}
            className="w-64 bg-sacred-sidebar border-r border-sacred-border flex flex-col p-4 z-40 shrink-0"
          >
            <div className="flex items-center gap-3 mb-8 px-2">
              <div className="w-8 h-8 bg-sacred-accent rounded-md flex items-center justify-center text-white font-serif italic text-xl">E</div>
              <span className="font-serif text-xl font-semibold tracking-tight text-sacred-ink">Escritura</span>
            </div>

            <div className="mb-6 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-sacred-muted" size={14} />
              <input
                type="text"
                placeholder="Buscar livro..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/50 border border-sacred-border rounded-full py-1.5 pl-9 pr-4 text-xs focus:outline-none focus:ring-1 focus:ring-sacred-accent"
              />
            </div>

            <div className="mb-6">
              <h3 className="text-[10px] uppercase tracking-widest text-sacred-muted font-bold mb-2 px-2">Tradução</h3>
              <select
                value={currentTranslation}
                onChange={(e) => setCurrentTranslation(e.target.value)}
                className="w-full bg-white/50 border border-sacred-border rounded-lg py-2 px-3 text-xs focus:outline-none focus:ring-1 focus:ring-sacred-accent"
              >
                {AVAILABLE_TRANSLATIONS.map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-6 pr-1">
              <div>
                <h3 className="text-xs uppercase tracking-widest text-sacred-muted font-bold mb-3">Progresso de Estudo</h3>
                <div className="space-y-4">
                  <div className="p-4 bg-white/40 rounded-2xl border border-sacred-border">
                    <div className="flex justify-between items-end mb-2">
                      <span className="text-[10px] uppercase font-bold text-sacred-muted tracking-tight">Bíblia</span>
                      <span className="text-xs font-bold text-sacred-accent">{completedVerses.size} / {TOTAL_BIBLE_VERSES}</span>
                    </div>
                    <div className="h-1.5 w-full bg-black/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(completedVerses.size / TOTAL_BIBLE_VERSES) * 100}%` }}
                        className="h-full bg-sacred-accent"
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-white/40 rounded-2xl border border-sacred-border">
                    <div className="flex justify-between items-end mb-2">
                      <span className="text-[10px] uppercase font-bold text-sacred-muted tracking-tight">Símbolos de Fé</span>
                      <span className="text-xs font-bold text-sacred-accent">{completedConfessions.size} / {westminsterConfession.length}</span>
                    </div>
                    <div className="h-1.5 w-full bg-black/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(completedConfessions.size / westminsterConfession.length) * 100}%` }}
                        className="h-full bg-sacred-accent"
                      />
                    </div>
                    <p className="text-[9px] text-sacred-muted mt-2 italic leading-tight">Você completou {completedConfessions.size} estudos da CFW.</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xs uppercase tracking-widest text-sacred-muted font-bold mb-3">Confissão de Fé</h3>
                <div className="space-y-0.5">
                  {westminsterConfession.map((conf) => (
                    <button
                      key={conf.id}
                      onClick={() => handleConfessionSelect(conf)}
                      className={cn(
                        "sidebar-button text-left",
                        selectedConfession?.id === conf.id ? "sidebar-button-active" : "sidebar-button-inactive"
                      )}
                    >
                      <span className="opacity-50 mr-2 text-[9px]">{conf.id}.</span> {conf.title}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xs uppercase tracking-widest text-sacred-muted font-bold mb-3">Escrituras Sagradas</h3>
                {isBooksError ? (
                  <div className="py-10 text-center px-4">
                    <p className="text-[10px] text-red-500 mb-3">Erro ao carregar os livros. Verifique sua conexão.</p>
                    <button 
                      onClick={loadBooks}
                      className="px-4 py-1.5 bg-sacred-accent text-white text-[10px] rounded-full uppercase font-bold tracking-widest"
                    >
                      Tentar Novamente
                    </button>
                  </div>
                ) : books.length === 0 ? (
                  <div className="py-10 text-center">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                      className="inline-block w-4 h-4 border-2 border-sacred-accent/20 border-t-sacred-accent rounded-full mb-2"
                    />
                    <p className="text-[10px] text-sacred-muted">Carregando livraria...</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Antigo Testamento */}
                    <div>
                      <h4 className="text-[10px] uppercase font-bold text-sacred-muted/60 mb-2 px-2 flex items-center gap-2">
                        <div className="h-[1px] flex-1 bg-sacred-border"></div>
                        Antigo Testamento
                        <div className="h-[1px] flex-1 bg-sacred-border"></div>
                      </h4>
                      <div className="space-y-0.5">
                        {filteredBooks.filter(b => b.testament === 'AT').map((book) => (
                          <button
                            key={book.id}
                            onClick={() => {
                              setSelectedBook(book);
                              setChapter(1);
                            }}
                            className={cn(
                              "sidebar-button w-full text-left",
                              selectedBook?.id === book.id ? "sidebar-button-active" : "sidebar-button-inactive"
                            )}
                          >
                            {book.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Novo Testamento */}
                    <div>
                      <h4 className="text-[10px] uppercase font-bold text-sacred-muted/60 mb-2 px-2 flex items-center gap-2">
                        <div className="h-[1px] flex-1 bg-sacred-border"></div>
                        Novo Testamento
                        <div className="h-[1px] flex-1 bg-sacred-border"></div>
                      </h4>
                      <div className="space-y-0.5">
                        {filteredBooks.filter(b => b.testament === 'NT').map((book) => (
                          <button
                            key={book.id}
                            onClick={() => {
                              setSelectedBook(book);
                              setChapter(1);
                            }}
                            className={cn(
                              "sidebar-button w-full text-left",
                              selectedBook?.id === book.id ? "sidebar-button-active" : "sidebar-button-inactive"
                            )}
                          >
                            {book.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <h3 className="text-xs uppercase tracking-widest text-sacred-muted font-bold mb-3">Temas do Dia</h3>
                <div className="flex flex-wrap gap-2">
                  {['Amor Ágape', 'Soberania', 'Justificação', 'Redenção'].map((theme) => (
                    <span key={theme} className="px-2 py-1 bg-white border border-sacred-border rounded text-[11px] text-sacred-muted cursor-pointer hover:border-sacred-accent">
                      {theme}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-auto pt-4 border-t border-sacred-border">
              <div className="p-3 bg-sacred-accent/10 rounded-lg border border-sacred-accent/20">
                <p className="text-xs font-serif italic text-sacred-accent">"A tua palavra é lâmpada para os meus pés..."</p>
                <p className="text-[10px] text-right mt-1 text-sacred-muted">— Salmo 119:105</p>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 bg-sacred-sidebar border-b border-sacred-border flex items-center justify-between px-6 shrink-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-black/5 rounded-full text-sacred-muted">
              <Menu size={20} />
            </button>
            <div className="flex items-center gap-4 ml-2">
              <h1 className="font-serif text-xl font-semibold text-sacred-ink hidden sm:block">
                {selectedBook?.name}
              </h1>
              <div className="flex items-center gap-1 bg-white border border-sacred-border rounded-full px-2 py-0.5">
                <button onClick={() => setChapter(Math.max(1, chapter - 1))} className="p-1 hover:text-sacred-accent disabled:opacity-20" disabled={chapter === 1}>
                  <ChevronLeft size={16} />
                </button>
                <span className="text-xs font-bold px-2">{chapter}</span>
                <button onClick={() => setChapter(Math.min(selectedBook?.chapters || 1, chapter + 1))} className="p-1 hover:text-sacred-accent disabled:opacity-20" disabled={chapter === selectedBook?.chapters}>
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            {!user ? (
              <button
                onClick={signInWithGoogle}
                className="text-xs font-semibold px-4 py-2 border border-sacred-accent/20 rounded-full hover:bg-sacred-accent hover:text-white transition-all"
              >
                Entrar
              </button>
            ) : (
              <>
                <button
                  onClick={logOut}
                  className="p-2 hover:bg-black/5 rounded-full text-sacred-muted tooltip"
                  title="Sair"
                >
                  <LogOut size={20} />
                </button>
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || ""} className="w-8 h-8 rounded-full border border-white" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-sacred-border border border-white flex items-center justify-center text-[10px] font-bold">
                    {user.displayName?.charAt(0) || user.email?.charAt(0)}
                  </div>
                )}
              </>
            )}
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 flex overflow-hidden">
          <main className="flex-1 bg-white overflow-y-auto p-8 lg:p-12 custom-scrollbar" ref={scrollRef}>
            <div className="max-w-2xl mx-auto">
              {!selectedConfession ? (
                <>
                  <div className="mb-12 border-b border-sacred-sidebar pb-6">
                    <h2 className="font-serif text-5xl text-sacred-ink mb-2">Capítulo {chapter}</h2>
                    <p className="text-sacred-muted font-medium tracking-widest text-xs uppercase">{selectedBook?.name}</p>
                  </div>

                  <div className="space-y-8 bible-text text-xl leading-relaxed text-sacred-ink transition-all">
                    {isVersesError ? (
                      <div className="py-20 text-center px-4 bg-red-50 rounded-3xl border border-red-100">
                        <p className="text-red-500 mb-4 font-medium">Não conseguimos carregar os versículos deste capítulo.</p>
                        <button 
                          onClick={loadVerses}
                          className="px-6 py-2 bg-red-500 text-white rounded-full text-sm font-bold uppercase tracking-widest hover:bg-red-600 transition-colors"
                        >
                          Tentar Novamente
                        </button>
                      </div>
                    ) : verses.length === 0 ? (
                      <div className="py-20 text-center">
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                          className="inline-block w-8 h-8 border-4 border-sacred-accent/20 border-t-sacred-accent rounded-full mb-4"
                        />
                        <p className="text-sacred-muted">Buscando escrituras...</p>
                      </div>
                    ) : (
                      verses.map((v) => (
                        <motion.div
                          key={v.pk}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          onClick={() => handleVerseSelect(v)}
                          className={cn(
                            "group cursor-pointer relative -mx-4 px-4 py-3 rounded-xl transition-all duration-300",
                            selectedVerse?.pk === v.pk ? "bg-sacred-sidebar border-l-4 border-sacred-accent shadow-sm" : "hover:bg-sacred-sidebar/30"
                          )}
                        >
                          <span className="text-sacred-muted text-sm font-sans align-top mr-4 opacity-50 group-hover:opacity-100">
                            {v.verse}
                          </span>
                          <span className={cn(selectedVerse?.pk === v.pk ? "font-medium" : "opacity-90")}>
                            {v.text}
                          </span>
                        </motion.div>
                      ))
                    )}
                  </div>
                </>
              ) : (
                <div className="py-20 text-center">
                  <div className="w-16 h-16 bg-sacred-accent/10 rounded-full flex items-center justify-center text-sacred-accent mx-auto mb-6">
                    <Book size={32} />
                  </div>
                  <h2 className="font-serif text-4xl text-sacred-ink mb-4">{selectedConfession.title}</h2>
                  <p className="text-sacred-muted uppercase tracking-widest text-xs mb-10">Confissão de Fé de Westminster • Capítulo {selectedConfession.id}</p>
                  
                  <div className="p-8 bg-sacred-sidebar rounded-3xl border border-sacred-border text-left leading-relaxed text-lg italic text-sacred-ink/80">
                    O texto completo deste capítulo está sendo analisado abaixo. Utilize o painel de estudos à direita para ver o mapa mental e comentários teológicos.
                  </div>
                </div>
              )}

              <div className="mt-20 mb-32 p-10 bg-sacred-sidebar/50 rounded-3xl border border-sacred-border border-dashed text-center">
                <Heart size={32} className="mx-auto text-sacred-accent mb-4 opacity-40" />
                <h3 className="font-serif text-2xl font-bold mb-2">Ajude na Obra</h3>
                <p className="text-sacred-muted mb-6 max-w-md mx-auto">
                  Sua ajuda permite a manutenção desta plataforma e o apoio direto aos missionários no campo de Guanambi, Bahia.
                </p>
                <button 
                  onClick={() => setIsDonationOpen(true)}
                  className="px-8 py-3 bg-sacred-accent text-white rounded-full font-bold shadow-lg shadow-sacred-accent/20 hover:scale-105 transition-transform"
                >
                  Fazer uma doação
                </button>
              </div>
            </div>
          </main>

          {/* Study Sidebar */}
          <AnimatePresence>
            {(selectedVerse || selectedConfession) && (
              <motion.aside
                initial={{ x: 400, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 400, opacity: 0 }}
                className="w-full lg:w-[450px] bg-sacred-sidebar border-l border-sacred-border flex flex-col z-20 shadow-[-10px_0_30px_rgba(0,0,0,0.05)]"
              >
                <div className="p-4 bg-white/80 backdrop-blur-md border-b border-sacred-border flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-sacred-accent/10 flex items-center justify-center text-sacred-accent">
                      <Sparkles size={16} />
                    </div>
                    <h3 className="text-sm font-bold text-sacred-ink uppercase">
                      {selectedVerse ? "Estudo do Versículo" : "Estudo da Confissão"}
                    </h3>
                  </div>
                  <button onClick={() => { setSelectedVerse(null); setSelectedConfession(null); }} className="p-2 hover:bg-black/5 rounded-full text-sacred-muted">
                    <X size={18} />
                  </button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                  {selectedVerse && (
                    <div className="mb-8 p-6 bg-white border border-sacred-border rounded-xl shadow-sm">
                      <p className="text-xs font-bold text-sacred-accent/40 mb-2 uppercase tracking-widest">{selectedBook?.name} {chapter}:{selectedVerse.verse}</p>
                      <p className="font-serif text-lg italic text-sacred-ink leading-relaxed">"{selectedVerse.text}"</p>
                    </div>
                  )}

                  {selectedConfession && (
                    <div className="mb-8 p-6 bg-white border border-sacred-border rounded-xl shadow-sm">
                      <p className="text-xs font-bold text-sacred-accent/40 mb-2 uppercase tracking-widest">Confissão de Fé de Westminster</p>
                      <p className="font-serif text-lg italic text-sacred-ink leading-relaxed">{selectedConfession.title}</p>
                    </div>
                  )}

                  <StudyPanel 
                    study={study || ({} as any)} 
                    isLoading={isStudyLoading} 
                    onReferenceClick={handleReferenceClick}
                    onComplete={handleStudyComplete}
                    isCompleted={selectedVerse ? completedVerses.has(selectedVerse.pk.toString()) : !!selectedConfession && completedConfessions.has(selectedConfession.id.toString())}
                    isLoggedIn={!!user}
                  />
                </div>
              </motion.aside>
            )}
          </AnimatePresence>
        </div>
      </div>

      <DonationPopup isOpen={isDonationOpen} onClose={() => setIsDonationOpen(false)} />

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 5px; height: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e5dfd3; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #5a5a4080; }
      `}</style>
    </div>
  );
}
